﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(_7778_PRG522.Startup))]
namespace _7778_PRG522
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
